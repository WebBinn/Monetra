import 'dart:async';
import 'dart:math' as math;
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

const emerald = Color(0xFF10B981), coral = Color(0xFFFF6B6B), bgDark = Color(0xFF0B1020), cardDark = Color(0xFF141B2E);
const palette = [Color(0xFFFF6B6B), Color(0xFFFFB84D), Color(0xFF4DA3FF), Color(0xFFB57BFF), Color(0xFF10B981), Color(0xFFFF7BC8), Color(0xFF3DD6D0), Color(0xFFA3E635), Color(0xFF94A3B8), Color(0xFFF97316)];
const expCats = ['Makanan & Minuman', 'Transportasi / Bensin', 'Belanja', 'Rokok', 'Tagihan', 'Hiburan', 'Kesehatan', 'Pendidikan', 'Kebutuhan Rumah', 'Lainnya'];
const incCats = ['Gaji', 'Lembur', 'Trading', 'Bonus', 'Usaha', 'Lainnya'];
const methods = ['Tunai', 'Transfer', 'E-wallet', 'Lainnya'];
const periods = ['Hari ini', '7 hari', 'Bulan ini', 'Bulan lalu', 'Tahun ini', 'Kustom'];
final rp = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

// ---------- Model & penyimpanan (SQLite). Nominal disimpan sebagai INTEGER rupiah: tanpa pembulatan. ----------
class Tx {
  int? id; bool income; int amount; String title, cat, note, method; DateTime at;
  Tx({this.id, required this.income, required this.amount, required this.title, required this.cat, this.note = '', this.method = 'Tunai', required this.at});
  Map<String, Object?> toMap() => {'id': id, 'income': income ? 1 : 0, 'amount': amount, 'title': title, 'cat': cat, 'note': note, 'method': method, 'at': at.millisecondsSinceEpoch};
  factory Tx.from(Map<String, Object?> m) => Tx(id: m['id'] as int, income: m['income'] == 1, amount: m['amount'] as int, title: m['title'] as String, cat: m['cat'] as String, note: m['note'] as String, method: m['method'] as String, at: DateTime.fromMillisecondsSinceEpoch(m['at'] as int));
}

class Store extends ChangeNotifier {
  late Database db; late SharedPreferences sp;
  List<Tx> all = []; int initial = 0; bool dark = true; List<String> customCats = [];

  Future<void> init() async {
    sp = await SharedPreferences.getInstance();
    initial = sp.getInt('initial') ?? 0; dark = sp.getBool('dark') ?? true; customCats = sp.getStringList('cats') ?? [];
    db = await openDatabase(p.join(await getDatabasesPath(), 'monetra.db'), version: 1,
        onCreate: (d, v) => d.execute('CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT, income INTEGER NOT NULL, amount INTEGER NOT NULL CHECK(amount > 0), title TEXT NOT NULL, cat TEXT NOT NULL, note TEXT NOT NULL, method TEXT NOT NULL, at INTEGER NOT NULL)'));
    await load();
  }
  Future<void> load() async { all = (await db.query('tx', orderBy: 'at ASC, id ASC')).map(Tx.from).toList(); notifyListeners(); }
  Future<void> save(Tx t) async {
    if (t.id == null) { await db.insert('tx', t.toMap()..remove('id')); } else { await db.update('tx', t.toMap(), where: 'id=?', whereArgs: [t.id]); }
    await load();
  }
  Future<void> del(int id) async { all = all.where((t) => t.id != id).toList(); notifyListeners(); await db.delete('tx', where: 'id=?', whereArgs: [id]); }
  Future<void> reset() async { all = []; notifyListeners(); await db.delete('tx'); }
  Future<void> setInitial(int v) async { initial = v; notifyListeners(); await sp.setInt('initial', v); }
  Future<void> setDark(bool v) async { dark = v; notifyListeners(); await sp.setBool('dark', v); }
  Future<void> addCat(String c) async { customCats = [...customCats, c]; notifyListeners(); await sp.setStringList('cats', customCats); }
  Future<void> delCat(String c) async { customCats = customCats.where((x) => x != c).toList(); notifyListeners(); await sp.setStringList('cats', customCats); }

  int get balance => initial + all.fold<int>(0, (s, t) => s + (t.income ? t.amount : -t.amount));
  Map<int, int> get running { var b = initial; final m = <int, int>{}; for (final t in all) { b += t.income ? t.amount : -t.amount; m[t.id!] = b; } return m; }
  List<Tx> between(DateTime a, DateTime b) => all.where((t) => !t.at.isBefore(a) && t.at.isBefore(b)).toList();
}

final store = Store();

// ---------- Helper ----------
int sum(Iterable<Tx> l, bool inc) => l.where((t) => t.income == inc).fold<int>(0, (s, t) => s + t.amount);
List<String> catsFor(bool inc) => [...(inc ? incCats : expCats), ...store.customCats.where((c) => c.startsWith(inc ? 'i:' : 'e:')).map((c) => c.substring(2))];
List<MapEntry<String, int>> catTotals(Iterable<Tx> l) {
  final m = <String, int>{};
  for (final t in l.where((t) => !t.income)) { m[t.cat] = (m[t.cat] ?? 0) + t.amount; }
  return m.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
}
(DateTime, DateTime) rangeOf(String k, DateTimeRange? custom) {
  final n = DateTime.now(), t = DateTime(n.year, n.month, n.day);
  switch (k) {
    case 'Hari ini': return (t, DateTime(t.year, t.month, t.day + 1));
    case '7 hari': return (DateTime(t.year, t.month, t.day - 6), DateTime(t.year, t.month, t.day + 1));
    case 'Bulan ini': return (DateTime(n.year, n.month), DateTime(n.year, n.month + 1));
    case 'Bulan lalu': return (DateTime(n.year, n.month - 1), DateTime(n.year, n.month));
    case 'Tahun ini': return (DateTime(n.year), DateTime(n.year + 1));
    default:
      final r = custom ?? DateTimeRange(start: t, end: t);
      return (DateTime(r.start.year, r.start.month, r.start.day), DateTime(r.end.year, r.end.month, r.end.day + 1));
  }
}
Widget box(BuildContext c, Widget child, {EdgeInsets p = const EdgeInsets.all(16)}) => Container(margin: const EdgeInsets.only(bottom: 14), padding: p, decoration: BoxDecoration(color: Theme.of(c).colorScheme.surface, borderRadius: BorderRadius.circular(22)), width: double.infinity, child: child);
Widget h(String s) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(s, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)));
Widget stat(String l, int v, [Color? col]) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(l, style: const TextStyle(fontSize: 12, color: Colors.grey)), const SizedBox(height: 2), Text(rp.format(v), style: TextStyle(fontWeight: FontWeight.w700, color: col))]);
void openForm(BuildContext c, {bool income = false, Tx? edit}) => Navigator.push(c, MaterialPageRoute(builder: (_) => TxForm(income: income, edit: edit)));
Future<bool> confirm(BuildContext c, String t, String m) async => await showDialog<bool>(context: c, builder: (d) => AlertDialog(title: Text(t), content: Text(m), actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Batal')), TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Ya, lanjutkan'))])) ?? false;
Future<String?> ask(BuildContext c, String title, {bool num = false, String init = ''}) {
  final ctl = TextEditingController(text: init);
  return showDialog<String>(context: c, builder: (d) => AlertDialog(title: Text(title), content: TextField(controller: ctl, autofocus: true, keyboardType: num ? const TextInputType.numberWithOptions(signed: true) : TextInputType.text), actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Batal')), TextButton(onPressed: () => Navigator.pop(d, ctl.text.trim()), child: const Text('Simpan'))]));
}
FlTitlesData titles(List<DateTime> k, bool mo) => FlTitlesData(
    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
    leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
    bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 24, interval: math.max(1, (k.length / 6).ceil()).toDouble(),
        getTitlesWidget: (v, _) => v.toInt() < k.length ? Padding(padding: const EdgeInsets.only(top: 6), child: Text(DateFormat(mo ? 'MMM' : 'd', 'id_ID').format(k[v.toInt()]), style: const TextStyle(fontSize: 10))) : const SizedBox())));

// ---------- App ----------
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('id_ID');
  await store.init();
  runApp(const App());
}

ThemeData _theme(Brightness b) {
  final d = b == Brightness.dark;
  return ThemeData(useMaterial3: true, brightness: b, scaffoldBackgroundColor: d ? bgDark : const Color(0xFFF4F6FB),
      colorScheme: ColorScheme.fromSeed(seedColor: emerald, brightness: b, surface: d ? cardDark : Colors.white));
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c) => ListenableBuilder(listenable: store, builder: (_, __) => MaterialApp(
      title: 'Monetra', debugShowCheckedModeBanner: false, themeMode: store.dark ? ThemeMode.dark : ThemeMode.light,
      theme: _theme(Brightness.light), darkTheme: _theme(Brightness.dark), home: const Shell()));
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  @override
  Widget build(BuildContext c) => Scaffold(
      body: IndexedStack(index: i, children: const [Dash(), TxPage(), StatsPage(), SettingsPage()]),
      bottomNavigationBar: NavigationBar(selectedIndex: i, onDestinationSelected: (v) => setState(() => i = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Dashboard'),
        NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Transaksi'),
        NavigationDestination(icon: Icon(Icons.pie_chart_outline), selectedIcon: Icon(Icons.pie_chart), label: 'Statistik'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Pengaturan'),
      ]));
}

// ---------- Dashboard ----------
class Dash extends StatefulWidget {
  const Dash({super.key});
  @override
  State<Dash> createState() => _DashState();
}

class _DashState extends State<Dash> {
  DateTime now = DateTime.now(); late Timer tm;
  @override
  void initState() { super.initState(); tm = Timer.periodic(const Duration(seconds: 1), (_) => setState(() => now = DateTime.now())); }
  @override
  void dispose() { tm.cancel(); super.dispose(); }
  @override
  Widget build(BuildContext c) => ListenableBuilder(listenable: store, builder: (_, __) {
        final m = rangeOf('Bulan ini', null), d = rangeOf('Hari ini', null);
        final mt = store.between(m.$1, m.$2), dt = store.between(d.$1, d.$2);
        final inc = sum(mt, true), exp = sum(mt, false), left = inc - exp, bal = store.balance;
        final used = inc > 0 ? exp * 100 / inc : (exp > 0 ? 100.0 : 0.0);
        final recent = store.all.reversed.take(5).toList(); final run = store.running;
        return SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
          const Text('Monetra', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          Text(DateFormat('EEEE, d MMMM y • HH:mm:ss', 'id_ID').format(now), style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 16),
          box(c, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Total saldo', style: TextStyle(color: Colors.grey)),
            Text(rp.format(bal), style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: bal < 0 ? coral : null)),
            const SizedBox(height: 16),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [stat('Pemasukan bulan ini', inc, emerald), stat('Pengeluaran bulan ini', exp, coral)]),
            const SizedBox(height: 14),
            stat('Sisa uang bulan ini', left, left < 0 ? coral : null),
            const SizedBox(height: 10),
            LinearProgressIndicator(value: (used / 100).clamp(0.0, 1.0).toDouble(), color: used > 100 ? coral : emerald, minHeight: 8, borderRadius: BorderRadius.circular(8)),
            const SizedBox(height: 6),
            Text('Terpakai ${used.toStringAsFixed(1)}% dari pemasukan', style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ])),
          Row(children: [
            Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: emerald, padding: const EdgeInsets.all(14)), onPressed: () => openForm(c, income: true), icon: const Icon(Icons.add), label: const Text('Pemasukan'))),
            const SizedBox(width: 12),
            Expanded(child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: coral, padding: const EdgeInsets.all(14)), onPressed: () => openForm(c), icon: const Icon(Icons.remove), label: const Text('Pengeluaran'))),
          ]),
          const SizedBox(height: 14),
          box(c, Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [stat('Pemasukan hari ini', sum(dt, true), emerald), stat('Pengeluaran hari ini', sum(dt, false), coral)])),
          box(c, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Pengeluaran per kategori (bulan ini)', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 12), CatPie(mt)])),
          const Padding(padding: EdgeInsets.only(bottom: 8), child: Text('Transaksi terbaru', style: TextStyle(fontWeight: FontWeight.w700))),
          if (recent.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('Belum ada transaksi'))),
          for (final t in recent) box(c, TxTile(t, run[t.id]), p: EdgeInsets.zero),
        ]));
      });
}

class CatPie extends StatelessWidget {
  final List<Tx> tx;
  const CatPie(this.tx, {super.key});
  @override
  Widget build(BuildContext c) {
    final e = catTotals(tx), tot = sum(tx, false);
    if (tot == 0) return const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('Belum ada pengeluaran')));
    return Column(children: [
      SizedBox(height: 200, child: PieChart(PieChartData(sectionsSpace: 2, centerSpaceRadius: 50, sections: [
        for (var i = 0; i < e.length; i++) PieChartSectionData(value: e[i].value.toDouble(), color: palette[i % palette.length], radius: 36, title: '${(e[i].value * 100 / tot).toStringAsFixed(0)}%', titleStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white))]))),
      const SizedBox(height: 12),
      Wrap(spacing: 12, runSpacing: 6, children: [for (var i = 0; i < e.length; i++) Row(mainAxisSize: MainAxisSize.min, children: [CircleAvatar(radius: 5, backgroundColor: palette[i % palette.length]), const SizedBox(width: 6), Text(e[i].key, style: const TextStyle(fontSize: 12))])]),
    ]);
  }
}

class TxTile extends StatelessWidget {
  final Tx t; final int? after;
  const TxTile(this.t, this.after, {super.key});
  @override
  Widget build(BuildContext c) {
    final col = t.income ? emerald : coral;
    return ListTile(
        onTap: () => openForm(c, edit: t),
        leading: CircleAvatar(backgroundColor: col.withOpacity(.15), child: Icon(t.income ? Icons.south_west : Icons.north_east, color: col, size: 18)),
        title: Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('${t.cat} • ${DateFormat('d MMM y, HH:mm', 'id_ID').format(t.at)}', style: const TextStyle(fontSize: 12)),
        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('${t.income ? '+' : '-'}${rp.format(t.amount)}', style: TextStyle(color: col, fontWeight: FontWeight.w700)),
          if (after != null) Text('Saldo ${rp.format(after)}', style: TextStyle(fontSize: 11, color: after! < 0 ? coral : Colors.grey)),
        ]));
  }
}

// ---------- Form transaksi (tambah & edit) ----------
class TxForm extends StatefulWidget {
  final Tx? edit; final bool income;
  const TxForm({super.key, this.edit, this.income = false});
  @override
  State<TxForm> createState() => _TxFormState();
}

class _TxFormState extends State<TxForm> {
  late bool inc = widget.edit?.income ?? widget.income;
  late final amt = TextEditingController(text: widget.edit?.amount.toString() ?? '');
  late final title = TextEditingController(text: widget.edit?.title ?? '');
  late final note = TextEditingController(text: widget.edit?.note ?? '');
  late String cat = widget.edit?.cat ?? catsFor(inc).first, method = widget.edit?.method ?? methods.first;
  late DateTime at = widget.edit?.at ?? DateTime.now();
  bool touched = false;

  Future<void> _date() async {
    final d = await showDatePicker(context: context, initialDate: at, firstDate: DateTime(2000), lastDate: DateTime(2100));
    if (d != null) setState(() { touched = true; at = DateTime(d.year, d.month, d.day, at.hour, at.minute, at.second); });
  }
  Future<void> _time() async {
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(at));
    if (t != null) setState(() { touched = true; at = DateTime(at.year, at.month, at.day, t.hour, t.minute, at.second); });
  }
  Future<void> _save() async {
    final a = int.tryParse(amt.text) ?? 0;
    if (a <= 0) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nominal harus lebih dari 0'))); return; }
    await store.save(Tx(id: widget.edit?.id, income: inc, amount: a, title: title.text.trim().isEmpty ? cat : title.text.trim(), cat: cat, note: note.text.trim(), method: method,
        at: widget.edit == null && !touched ? DateTime.now() : at));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      appBar: AppBar(title: Text(widget.edit == null ? 'Transaksi baru' : 'Edit transaksi')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        SegmentedButton<bool>(segments: const [ButtonSegment(value: true, label: Text('Pemasukan')), ButtonSegment(value: false, label: Text('Pengeluaran'))], selected: {inc},
            onSelectionChanged: (s) => setState(() { inc = s.first; cat = catsFor(inc).first; })),
        const SizedBox(height: 16),
        TextField(controller: amt, keyboardType: TextInputType.number, inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(15)], decoration: const InputDecoration(labelText: 'Nominal', prefixText: 'Rp ', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: title, decoration: const InputDecoration(labelText: 'Nama transaksi', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: cat, decoration: const InputDecoration(labelText: 'Kategori', border: OutlineInputBorder()), items: {...catsFor(inc), cat}.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => cat = v!)),
        const SizedBox(height: 12),
        Wrap(spacing: 8, children: [for (final m in methods) ChoiceChip(label: Text(m), selected: method == m, onSelected: (_) => setState(() => method = m))]),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: _date, icon: const Icon(Icons.calendar_today, size: 16), label: Text(DateFormat('d MMM y', 'id_ID').format(at)))),
          const SizedBox(width: 12),
          Expanded(child: OutlinedButton.icon(onPressed: _time, icon: const Icon(Icons.schedule, size: 16), label: Text(DateFormat('HH:mm').format(at)))),
        ]),
        const SizedBox(height: 12),
        TextField(controller: note, maxLines: 2, decoration: const InputDecoration(labelText: 'Catatan (opsional)', border: OutlineInputBorder())),
        const SizedBox(height: 20),
        FilledButton(style: FilledButton.styleFrom(padding: const EdgeInsets.all(16), backgroundColor: inc ? emerald : coral), onPressed: _save, child: const Text('Simpan')),
      ]));
}

// ---------- Halaman transaksi ----------
class TxPage extends StatefulWidget {
  const TxPage({super.key});
  @override
  State<TxPage> createState() => _TxPageState();
}

class _TxPageState extends State<TxPage> {
  String per = 'Bulan ini', q = ''; bool? type; String? cat; bool newest = true;
  static const pers = ['Semua', 'Hari ini', '7 hari', 'Bulan ini', 'Tahun ini'];
  @override
  Widget build(BuildContext c) => ListenableBuilder(listenable: store, builder: (_, __) {
        final r = per == 'Semua' ? null : rangeOf(per, null), run = store.running;
        var l = store.all.where((t) => (r == null || (!t.at.isBefore(r.$1) && t.at.isBefore(r.$2))) && (type == null || t.income == type) && (cat == null || t.cat == cat) &&
            (q.isEmpty || '${t.title} ${t.cat} ${t.note}'.toLowerCase().contains(q.toLowerCase()))).toList();
        if (newest) l = l.reversed.toList();
        final cats = {...store.all.map((t) => t.cat)}.toList();
        return Scaffold(
            backgroundColor: Colors.transparent,
            floatingActionButton: FloatingActionButton(onPressed: () => openForm(c), child: const Icon(Icons.add)),
            body: SafeArea(child: Column(children: [
              Padding(padding: const EdgeInsets.fromLTRB(20, 20, 8, 0), child: Row(children: [Expanded(child: h('Transaksi')), IconButton(tooltip: 'Urutkan', onPressed: () => setState(() => newest = !newest), icon: Icon(newest ? Icons.arrow_downward : Icons.arrow_upward))])),
              Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: TextField(onChanged: (v) => setState(() => q = v), decoration: InputDecoration(hintText: 'Cari transaksi', prefixIcon: const Icon(Icons.search), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)), isDense: true))),
              SizedBox(height: 48, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 20), children: [for (final k in pers) Padding(padding: const EdgeInsets.only(right: 8, top: 8), child: ChoiceChip(label: Text(k), selected: per == k, onSelected: (_) => setState(() => per = k)))])),
              Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Wrap(spacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
                for (final (lb, v) in [('Semua', null), ('Masuk', true), ('Keluar', false)]) ChoiceChip(label: Text(lb), selected: type == v, onSelected: (_) => setState(() => type = v)),
                DropdownButton<String?>(value: cats.contains(cat) ? cat : null, underline: const SizedBox(), items: [const DropdownMenuItem(value: null, child: Text('Semua kategori')), ...cats.map((e) => DropdownMenuItem(value: e, child: Text(e)))], onChanged: (v) => setState(() => cat = v)),
              ])),
              Expanded(child: l.isEmpty
                  ? const Center(child: Text('Tidak ada transaksi'))
                  : ListView.builder(padding: const EdgeInsets.fromLTRB(20, 8, 20, 90), itemCount: l.length, itemBuilder: (_, i) {
                      final t = l[i];
                      return Dismissible(
                          key: ValueKey(t.id), direction: DismissDirection.endToStart,
                          background: Container(margin: const EdgeInsets.only(bottom: 14), decoration: BoxDecoration(color: coral, borderRadius: BorderRadius.circular(22)), alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20), child: const Icon(Icons.delete, color: Colors.white)),
                          confirmDismiss: (_) => confirm(c, 'Hapus transaksi?', '"${t.title}" akan dihapus permanen.'),
                          onDismissed: (_) => store.del(t.id!),
                          child: box(c, TxTile(t, run[t.id]), p: EdgeInsets.zero));
                    })),
            ])));
      });
}

// ---------- Statistik (semua dari database) ----------
class StatsPage extends StatefulWidget {
  const StatsPage({super.key});
  @override
  State<StatsPage> createState() => _StatsState();
}

class _StatsState extends State<StatsPage> {
  String per = 'Bulan ini'; DateTimeRange? custom;
  @override
  Widget build(BuildContext c) => ListenableBuilder(listenable: store, builder: (_, __) {
        final r = rangeOf(per, custom), a = r.$1, b = r.$2;
        final pr = per == 'Bulan ini' ? rangeOf('Bulan lalu', null) : per == 'Tahun ini' ? (DateTime(a.year - 1), a) : (a.subtract(b.difference(a)), a);
        final cur = store.between(a, b), prev = store.between(pr.$1, pr.$2);
        final mo = b.difference(a).inDays > 31;
        DateTime key(DateTime t) => mo ? DateTime(t.year, t.month) : DateTime(t.year, t.month, t.day);
        final keys = <DateTime>[];
        for (var d = key(a); d.isBefore(b); d = mo ? DateTime(d.year, d.month + 1) : DateTime(d.year, d.month, d.day + 1)) { keys.add(d); }
        final inc = {for (final k in keys) k: 0}, exp = {for (final k in keys) k: 0};
        for (final t in cur) { final m = t.income ? inc : exp; m[key(t.at)] = m[key(t.at)]! + t.amount; }
        var bal = store.initial + store.all.where((t) => t.at.isBefore(a)).fold<int>(0, (s, t) => s + (t.income ? t.amount : -t.amount));
        final spots = <FlSpot>[];
        for (var i = 0; i < keys.length; i++) { bal += inc[keys[i]]! - exp[keys[i]]!; spots.add(FlSpot(i.toDouble(), bal.toDouble())); }
        final ce = catTotals(cur), et = sum(cur, false), it = sum(cur, true);
        return SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
          h('Statistik'),
          SizedBox(height: 44, child: ListView(scrollDirection: Axis.horizontal, children: [
            for (final k in periods) Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: Text(k), selected: per == k, onSelected: (_) async {
              if (k == 'Kustom') {
                final d = await showDateRangePicker(context: c, firstDate: DateTime(2000), lastDate: DateTime(2100));
                if (d == null) return;
                custom = d;
              }
              setState(() => per = k);
            }))])),
          const SizedBox(height: 8),
          box(c, Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [stat('Pemasukan', it, emerald), stat('Pengeluaran', et, coral), stat('Selisih', it - et, it - et < 0 ? coral : null)])),
          box(c, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Pengeluaran per kategori', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 12), CatPie(cur)])),
          box(c, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Pemasukan vs pengeluaran', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 12),
            SizedBox(height: 200, child: BarChart(BarChartData(gridData: const FlGridData(show: false), borderData: FlBorderData(show: false), titlesData: titles(keys, mo), barTouchData: BarTouchData(enabled: false), barGroups: [
              for (var i = 0; i < keys.length; i++) BarChartGroupData(x: i, barRods: [
                BarChartRodData(toY: inc[keys[i]]!.toDouble(), color: emerald, width: keys.length > 15 ? 3 : 6),
                BarChartRodData(toY: exp[keys[i]]!.toDouble(), color: coral, width: keys.length > 15 ? 3 : 6)])]))),
          ])),
          box(c, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Perkembangan saldo', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 12),
            SizedBox(height: 200, child: LineChart(LineChartData(gridData: const FlGridData(show: false), borderData: FlBorderData(show: false), titlesData: titles(keys, mo), lineTouchData: const LineTouchData(enabled: false), lineBarsData: [
              LineChartBarData(spots: spots, isCurved: true, color: emerald, barWidth: 3, dotData: const FlDotData(show: false), belowBarData: BarAreaData(show: true, color: emerald.withOpacity(.12)))]))),
          ])),
          const Padding(padding: EdgeInsets.only(bottom: 8), child: Text('Detail kategori', style: TextStyle(fontWeight: FontWeight.w700))),
          for (var i = 0; i < ce.length; i++) Builder(builder: (_) {
            final k = ce[i].key, v = ce[i].value, n = cur.where((t) => !t.income && t.cat == k).length, pv = sum(prev.where((t) => t.cat == k), false);
            final up = v >= pv;
            return box(c, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [CircleAvatar(radius: 5, backgroundColor: palette[i % palette.length]), const SizedBox(width: 8), Expanded(child: Text(k, style: const TextStyle(fontWeight: FontWeight.w700))), Text(rp.format(v))]),
              const SizedBox(height: 4),
              Text('${(v * 100 / et).toStringAsFixed(1)}% • $n transaksi • rata-rata ${rp.format((v / n).round())}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
              Text(pv == 0 ? 'Tidak ada pengeluaran di periode sebelumnya' : '${up ? '▲' : '▼'} ${((v - pv).abs() * 100 / pv).toStringAsFixed(0)}% dibanding periode sebelumnya', style: TextStyle(fontSize: 12, color: pv == 0 ? Colors.grey : (up ? coral : emerald))),
            ]));
          }),
        ]));
      });
}

// ---------- Pengaturan ----------
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  String csv() => ['Tanggal,Jam,Nama,Kategori,Jenis,Nominal,Metode,Catatan',
        ...store.all.map((t) => [DateFormat('yyyy-MM-dd').format(t.at), DateFormat('HH:mm:ss').format(t.at), t.title, t.cat, t.income ? 'Pemasukan' : 'Pengeluaran', t.amount, t.method, t.note].map((e) => '"${e.toString().replaceAll('"', '""')}"').join(','))].join('\n');
  @override
  Widget build(BuildContext c) => ListenableBuilder(listenable: store, builder: (_, __) => SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
        h('Pengaturan'),
        box(c, Column(children: [
          SwitchListTile(title: const Text('Mode gelap'), value: store.dark, onChanged: store.setDark),
          ListTile(title: const Text('Saldo awal'), subtitle: Text(rp.format(store.initial)), trailing: const Icon(Icons.edit, size: 18), onTap: () async {
            final v = await ask(c, 'Saldo awal (Rupiah)', num: true, init: store.initial.toString());
            final n = int.tryParse(v ?? '');
            if (n != null) store.setInitial(n);
          }),
          for (final (lb, pre) in [('Tambah kategori pengeluaran', 'e:'), ('Tambah kategori pemasukan', 'i:')]) ListTile(title: Text(lb), trailing: const Icon(Icons.add), onTap: () async {
            final v = await ask(c, lb);
            if (v != null && v.isNotEmpty) store.addCat('$pre$v');
          }),
          for (final k in store.customCats) ListTile(title: Text(k.substring(2)), subtitle: Text(k.startsWith('i:') ? 'Pemasukan' : 'Pengeluaran'), trailing: IconButton(icon: const Icon(Icons.close), onPressed: () => store.delCat(k))),
          ListTile(title: const Text('Salin semua data sebagai CSV'), trailing: const Icon(Icons.copy, size: 18), onTap: () async {
            await Clipboard.setData(ClipboardData(text: csv()));
            if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('CSV disalin ke clipboard')));
          }),
          ListTile(title: const Text('Reset seluruh data', style: TextStyle(color: coral)), trailing: const Icon(Icons.delete_forever, color: coral), onTap: () async {
            if (await confirm(c, 'Reset seluruh data?', 'Semua transaksi akan dihapus permanen dan tidak bisa dikembalikan.')) store.reset();
          }),
        ]), p: EdgeInsets.zero),
        const Center(child: Text('Monetra 1.0 • Rupiah (IDR) • Data tersimpan lokal', style: TextStyle(fontSize: 12, color: Colors.grey))),
      ])));
}
