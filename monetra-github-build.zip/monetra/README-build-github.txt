MONETRA — Build APK via GitHub Actions

1. Buat repository GitHub baru dan upload seluruh isi folder `monetra` (termasuk folder `.github`).
2. Buka tab Actions di repository.
3. Pilih workflow "Build Monetra APK", lalu klik Run workflow.
4. Jika Analyze/Build gagal, buka log job dan salin error merah terakhir untuk diperbaiki.
5. Jika sukses, buka hasil run dan download artifact `monetra-release-apk` (ZIP artifact).
6. Ekstrak artifact, lalu instal `app-release.apk` di Android. Jika diminta, izinkan instalasi aplikasi dari sumber tersebut.

Catatan: Workflow menjalankan `flutter analyze` dan build release. Source belum pernah diverifikasi compile sebelum workflow dijalankan.
