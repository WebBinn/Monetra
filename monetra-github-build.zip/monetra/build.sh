#!/usr/bin/env bash
# Jalankan di komputer yang sudah terpasang Flutter SDK + Android SDK
set -e
flutter create --org id.monetra --project-name monetra --platforms android app
cp pubspec.yaml app/pubspec.yaml
rm -rf app/lib && cp -r lib app/lib
sed -i 's/android:label="monetra"/android:label="Monetra"/' app/android/app/src/main/AndroidManifest.xml
cd app && flutter pub get && flutter analyze && flutter build apk --release
echo "APK: app/build/app/outputs/flutter-apk/app-release.apk"
